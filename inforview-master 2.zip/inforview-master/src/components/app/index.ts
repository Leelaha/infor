export { StatApp } from "./app.component";
