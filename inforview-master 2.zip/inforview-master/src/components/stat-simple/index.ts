export { StatSimple } from "./stat-simple.component";
