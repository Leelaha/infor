export { StatChart } from "./stat-chart.component";
